"""Data files for longpass - wordlists and patterns."""
